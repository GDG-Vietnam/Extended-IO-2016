# Google I/O Extended 2016
Landing page for Google I/O Extended 2016 in Vietnam
